# TII Paper — Compilation Package
# Tikhonov Integral Inversion for Simultaneous State and Input Estimation
# IEEE Trans. Systems, Man, and Cybernetics: Systems

## Contents

    dual_hfnn_kalman_v2.tex   — Main LaTeX source (self-contained)
    IEEEtran.cls              — IEEE document class
    figures/
        motor_ground_truth.png    — Fig. 1: DC motor ground truth trajectories
        summary_publication.png   — Fig. 2: Comprehensive 6-panel results
        noise_scaling.png         — Fig. 3: RMSE vs noise (log-log)

## Compilation

    pdflatex dual_hfnn_kalman_v2.tex
    pdflatex dual_hfnn_kalman_v2.tex

Two passes are needed to resolve cross-references.

## Requirements

- pdflatex with standard packages (amsmath, amsthm, booktabs, algorithm, url)
- All packages are standard in TeX Live or MiKTeX

## Source Code

https://github.com/rodrigo1964-ai/Inversi-n-Integral-Regularizada

## Author

Rodolfo H. Rodrigo — UNSJ, San Juan, Argentina
